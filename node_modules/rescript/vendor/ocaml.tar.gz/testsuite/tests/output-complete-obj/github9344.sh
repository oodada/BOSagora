#!/bin/sh
export OCAMLRUNPARAM=b=1
./github9344 || true
