Array.iter (fun x -> print_endline (Filename.basename x)) Sys.argv;;
