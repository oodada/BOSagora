let () = print_endline "linked"; flush stdout
module M = struct end
