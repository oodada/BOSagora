let _, _ = External_for_pack.frexp 12.
