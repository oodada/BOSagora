let () = Makedepend.main ()
