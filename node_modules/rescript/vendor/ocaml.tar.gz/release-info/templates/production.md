## Announcing a production release:

```
Dear OCaml users,

We have the pleasure of celebrating <event> by announcing the release of
OCaml version $VERSION.
This is mainly a bug-fix release, see the list of changes below.

It is (or soon will be) available as a set of OPAM switches,
and as a source download here:
  https://caml.inria.fr/pub/distrib/ocaml-$BRANCH/

Happy hacking,

-- $HUMAN for the OCaml team.

<< insert the relevant Changes section >>
```
